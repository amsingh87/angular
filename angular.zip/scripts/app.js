'use strict';
//syntax for angular always with third part dependencies
angular.module("appName", []);